function id(elementId) {
    return document.getElementById(elementId)
}
class niños {
    constructor() {
        this.numeroAleatorio = Math.floor(Math.random()*10)+1
        this.cont = 3
    }
    adivina_el_numero(){

        //se reinicia el boton de aceptar
        let btnAceptar = id('boton2');
        btnAceptar.disabled = false
        //se desactiva el boton de reiniciar
        let btnReiniciar = id('reiniciar');
        btnReiniciar.disabled = true;
        //pido el numero
        let num = parseInt(document.getElementById("num").value)

        if(num != this.numeroAleatorio && this.cont > 0) {
            this.cont--;
            document.getElementById("respuesta").innerHTML += ` <br> Lo siento, te quedan ${this.cont} intentos.`
            document.getElementById("mostrar").innerHTML = "😞"
        }
        if(num == this.numeroAleatorio){
            //una vez ganado se activa el boton de reiniciar
            //y se desactiva el boton de aceptar
            btnReiniciar.disabled = false
            btnAceptar.disabled = true
            document.getElementById("respuesta").innerHTML += "<br> ¡Felicidades! Has adivinado el número."
            document.getElementById("mostrar").innerHTML = "😁"
        } else if(this.cont == 0) {
            //una vez ganado se activa el boton de reiniciar
            //y se desactiva el boton de aceptar
            btnReiniciar.disabled = false 
            btnAceptar.disabled = true
            document.getElementById("respuesta").innerHTML += ` <br> Perdiste, el número era el ${this.numeroAleatorio}. Inténtalo de nuevo.`
            document.getElementById("mostrar").innerHTML = "😭"
        }
    }
}

let juegos = new niños()

// Añade un evento al elemento de entrada para que llame a la función cada vez que el usuario presione enter
document.getElementById("num").addEventListener("keyup", function(event) {
    if (event.key === "Enter") {
        juegos.adivina_el_numero()
    }
});

