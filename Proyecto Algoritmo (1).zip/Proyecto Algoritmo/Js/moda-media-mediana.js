
let btn = id('boton2')
btn = addEventListener('click', iniciar)

function id(elementId) {
    return document.getElementById(elementId)
}

function iniciar(event) {
    //pido los valore
    let num = parseInt(id('num').value)
    let numeros = id('numeros').value

    numeros = numeros.split(',')

    //Convierto los numeros de texto a numeros
    for (let i = 0; i < numeros.length; i++) {
        numeros[i] = parseInt(numeros[i]) 
    }

    // Reinicio los spans en el elemento con el ID "valores"
    let valoresElement = id('valores')
    valoresElement.innerHTML = ''
 
    // Agrego spans al elemento con el ID "valores"
    for (let i = 0; i < num; i++) {
        let span = document.createElement('span')
        span.textContent = numeros[i] // Agrego los valores del array
        valoresElement.appendChild(span)
    }


    calcular(numeros,num)

}
function calcular(array,num) {
    //calculo

    let sumas_element=0
    for (let i = 0; i < array.length; i++) {
        sumas_element += array[i]
    }

    
    id("suma").innerHTML = `La Suma de los elementos es: ${sumas_element}`
    
    let media = calcularMedia(sumas_element,num)
    id("media").innerHTML = `<br> La Media es :${media}`

    //calculo moda
    let moda = calcularModa(array)
    id("moda").innerHTML = `<br> La Moda es: ${moda}`


    //calculo mediana
    let mediana = calcularMediana(array)
    id("mediana").innerHTML = `<br> La Mediana es: ${mediana}`

}
function calcularModa(array) {
    let frecuencia = {}
    let maxima_frecuencia = 0 
    let modas = []

    for(let i = 0; i < array.length; i++) {
        // recorremos cada elemento del array
        let valor = array[i]
        if(frecuencia[valor]) { 
            // si el valor ya existe en el objeto, incrementamos su frecuencia
            frecuencia[valor]++
        } else { 
            // si el valor no existe en el objeto, lo añadimos con frecuencia 1
            frecuencia[valor] = 1
        }

        if(frecuencia[valor] > maxima_frecuencia) { 
            // si la frecuencia del valor actual es mayor que maxFrec, actualizamos maxFrec y vaciamos el array modas
            maxima_frecuencia = frecuencia[valor]
            modas = [valor]
        } else if (frecuencia[valor] === maxima_frecuencia) { 
            // si la frecuencia del valor actual es igual a maxFrec, añadimos el valor al array modas
            modas.push(valor)
        }
    }

    return modas;
}
function calcularMedia(sumas,num) {
    let resultado = sumas / num

    resultado = resultado.toFixed(2)

    return resultado
}
function calcularMediana(array) {
    
    //se ordena de menor a mayor
    array.sort((a, b) => a - b) 

    let respuesta
    let mitad = Math.floor(array.length / 2)

    if (array.length % 2 === 0) { 
        // si la longitud del array es par
        respuesta = (array[mitad - 1] + array[mitad]) / 2
    } else { 
        // si la longitud del array es impar
        respuesta = array[mitad]
    }

    return respuesta;
}