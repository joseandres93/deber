document.addEventListener('DOMContentLoaded', function () {
    // Obtén todos los botones con la clase "animales"
    let botonesAnimales = document.querySelectorAll('.animales');

    // Agrega un evento de clic a cada botón
    botonesAnimales.forEach(function (boton) {
        boton.addEventListener('click', function (event) {
            // Obtén el valor del botón clickeado
            let valorBoton = event.target.value;

            // Reproduce el audio correspondiente al animal
            reproducirAudio(valorBoton);

            // Actualiza el contenido del div con el id "respuesta"
            id('respuesta').innerHTML = `<br> <br> El animal selecionado es:`;
            id('respuesta').innerHTML += `<br> <br> [ ${valorBoton} ]`;
            id('respuesta').innerHTML += `<br> <br> 😊`;
        });
    });

    // Función para reproducir el audio
    function reproducirAudio(animal) {
        // Pausa todos los audios antes de reproducir el nuevo
        detenerAudios();

        // Obtén el elemento de audio correspondiente al animal
        let audioElement = document.getElementById('audio' + animal.charAt(0).toUpperCase() + animal.slice(1));

        // Verifica si el elemento de audio existe y lo reproduce
        if (audioElement) {
            audioElement.play();
        }
    }

    // Función para detener todos los audios
    function detenerAudios() {
        let audios = document.querySelectorAll('audio');
        audios.forEach(function (audio) {
            audio.pause();
        });
    }
});

function id(elementId) {
    return document.getElementById(elementId);
}
