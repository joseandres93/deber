

let pantalla = document.querySelector(".pantalla")

//obtenemos el id de cada boton 
let botones = document.querySelectorAll(".btn")

//recorremos cada boton 
botones.forEach(boton => {
    boton.addEventListener("click", () => {
        console.log(boton.textContent)
        //obtenemos el contenido de texto de cada boton cuandoes apretado
        let botonApretado = boton.textContent

        //si el boton apretado es C pues se borra todo el contenido a 0
        if (boton.id === "c") {
            pantalla.textContent = "0"
            return
        }

        //si el boton a pretado es ← pues se borrara el ultimo texto
        if (boton.id === "borrar") {
            //si el texto dentro de pantalla es uno cuando la tecla apretada es ← se colocara 0 
            if (pantalla.textContent.length === 1 || pantalla.textContent === "Error!") {
                pantalla.textContent = "0"
            }else{
                //sino borrara el ultimo caracter
                pantalla.textContent = pantalla.textContent.slice(0, -1)
            }
            return
        }

        //si la tecla apretada es = pues con el comandp eval se evalua si es una operacion matematica
        //Tambien se usa el metodo try para comprobar los error al ingresar demasiados operadores sin sentido
        if (boton.id === "igual") {
            try{
                pantalla.textContent = eval(pantalla.textContent)
            }catch {
                pantalla.textContent = "Error!"
            }
            return
        }

        // si el boton es cero se lo remplaza por el contenido del boton apretado y si en la pantalla muestra el mensaje de error, pues que reemplaza con el valor de boton seleccionado
        if (pantalla.textContent === "0" || pantalla.textContent === "Error!") {
            pantalla.textContent = botonApretado
        }else {
            //si el texto no es 0 se concatena el contenido de los demas botones
            pantalla.textContent += botonApretado
        }
    })
})
