//variables
let card = document.querySelectorAll('.card') 
let start = document.querySelector('.start')
let contenidoCartas = ["😊","💣","🎶","🎃", "👻", "🎁","🏀", "😎", "🚗","👳‍♂️", "⚽","🌹", "👻","🎃","💣","🏀", "🚗", "⚽","🌹","👳‍♂️" ,"😊","🎶", "😎", "🎁"]
let cartasSeleccionadas = [];
let movimientos = 0;
let aciertos = 0;

//eventos

document.addEventListener('DOMContentLoaded', () =>{
    //na vez cargado todo el DOM se iniciar el juego
    iniciarApp()
})

start.addEventListener('click' , () => {
    //cuando el usuario haga click en boton jugar se llama a la funcion cronometro
    cronometro()
})
//funciones
function iniciarApp() {
    //al iniciar el juego los botones estaran bloqueados
    for (let i = 0; i < card.length; i++) {
        card[i].disabled = true
    }
    
    contenidoCartas = shuffleArray(contenidoCartas);

    // Reiniciar contadores
    movimientos = 0;
    aciertos = 0;

    document.getElementById('contador_aciertos').innerHTML = aciertos;
    document.getElementById('contador_estadisticas').innerHTML = movimientos;

    for (let i = 0; i < card.length; i++) {
        // Ocultar el contenido inicialmente
        card[i].innerHTML = '';
    }


}
//Mescla aleatoriamente el contenido
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function desbloquearCard() {
    //funcion para desbloquear botones
    for (let i = 0; i < card.length; i++) {
        card[i].disabled = false
    }
}

function cronometro() {
    //se llama a la funcion para que desblloque los botones
    desbloquearCard()
    //se define el tiempo que tendra el usuario
    let time = 60
    //una ves comenzado el juego se blloquea el boton de jugar
    start.classList.add("disabled")

    let contador = setInterval(() => {
        time--;

        //se muestra el contador de tiempo en pantalla
        contador_cronometro.innerHTML = time
        //una vez que el tiempo llega a cero se muestra una alerta

        if (time == 0) {
            clearInterval(contador);

            if (todosLosParesEncontrados()) {
                // Todos los pares encontrados, mostrar mensaje de "Has ganado"
                Swal.fire({
                    position: "center",
                    icon: "success",
                    title: "¡Has ganado!",
                    showConfirmButton: true,
                }).then(() => {
                    // Reiniciar el juego
                    location.reload();
                });
            } else {
                // No todos los pares encontrados, mostrar mensaje de "Se te acabó el tiempo"
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: "Se te acabó el tiempo",
                    showConfirmButton: true,
                }).then(() => {
                    // Recargar la página para reiniciar el juego
                    location.reload();
                });
            }
        }
    }, 1000);
}

function destapar(indice) {
    // Evitar hacer clic en una carta ya seleccionada o si ya hay dos cartas destapadas
    if (cartasSeleccionadas.length === 2 || card[indice].disabled) {
        return;
    }

    card[indice].innerHTML = contenidoCartas[indice];
    card[indice].disabled = true;

    cartasSeleccionadas.push({
        indice,
        contenido: contenidoCartas[indice]
    });

    if (cartasSeleccionadas.length === 2) {
        // Dos cartas seleccionadas, incrementar movimientos
        movimientos++;
        document.getElementById('contador_estadisticas').innerHTML = movimientos;

        if (cartasSeleccionadas[0].contenido === cartasSeleccionadas[1].contenido) {
            // Cartas forman un par
            aciertos++;
            document.getElementById('contador_aciertos').innerHTML = aciertos;

            if (todosLosParesEncontrados()) {
                // Todos los pares encontrados, mostrar mensaje de "Has ganado"
                Swal.fire({
                    position: "center",
                    icon: "success",
                    title: "¡Has ganado!",
                    showConfirmButton: true,
                }).then(() => {
                    // Reiniciar el juego
                    location.reload();
                });
            }

            cartasSeleccionadas = [];
        } else {
            // Cartas no forman un par, esperar un momento y luego voltearlas de nuevo
            setTimeout(() => {
                cartasSeleccionadas.forEach(carta => {
                    card[carta.indice].innerHTML = '';
                    card[carta.indice].disabled = false;
                });
                cartasSeleccionadas = [];
            }, 1000);
        }
    }
}
function todosLosParesEncontrados() {
    console.log(aciertos, card.length);
    return aciertos * 2 === card.length;
}