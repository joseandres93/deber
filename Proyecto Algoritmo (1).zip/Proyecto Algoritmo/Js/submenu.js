let listElement = document.querySelectorAll(`.list_button--click`);

listElement.forEach(listElement => {
    listElement.addEventListener(`click`, ()=>{
        
        //se le coloca una clase al hijo de list_button--click
        listElement.classList.toggle(`arrow`);

        let height = 0;
        let menu = listElement.nextElementSibling;

        //se imprime en consola el minimo de altura que se necesita para que exita el despliege de los submenus
        console.log(menu.scrollHeight)

        //se coloca una condicional para dar animacion al despliege de los submenu
        if (menu.clientHeight == "0") {
            height = menu.scrollHeight;
        }

        menu.style.height =`${height}px`;
    })
});