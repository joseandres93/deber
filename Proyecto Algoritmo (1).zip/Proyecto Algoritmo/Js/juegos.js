let cant_correcto = 0
let cant_errores = 0
class jovenes {
    area_de_un_triangulo(){
        
        //pido los valores
        let base = parseInt(document.getElementById("base").value)
        let altura = parseInt(document.getElementById("altura").value)

        //calculo
        let respuesta = (base * altura) / 2

        //presento
        document.getElementById("respuesta").innerHTML = `Respuesta`
        document.getElementById("respuesta").innerHTML += `<br> ${base} * ${altura} / 2 = [${respuesta}]`
        //presento el proceso
        document.getElementById("respuesta").innerHTML += `<br> <br> Para calcular el area de un triangulo tenemos que tener en cuenta que necesitamos la (Base) = ${base} y la (Altura) = ${altura} del triangulo luego simplemente remplazamos en la formula los datos `
        document.getElementById("respuesta"). innerHTML += `<br> <br> base * altura / 2 = ??`
        document.getElementById("respuesta"). innerHTML += `<br> <br> De esa manera obtenemos el area del triangulo. Espero y te ayude😉.`
    }
    area_de_un_cuadrado(){

        //pido los  valores
        let base = parseInt(document.getElementById("base").value)
        let altura = parseInt(document.getElementById("altura").value)

        //calculo
        let respuesta = base * altura

        //presento
        document.getElementById("respuesta").innerHTML = `Respuesta`
        document.getElementById("respuesta").innerHTML += `<br> ${base} * ${altura} = [${respuesta}]`
        //presento el proceso
        document.getElementById("respuesta").innerHTML += `<br> <br> Para calcular el area de un cuadrado tenemos que tener en cuenta que necesitamos la (Base) = ${base} y la (Altura) = ${altura} del cuadrado luego simplemente remplazamos en la formula los datos `
        document.getElementById("respuesta"). innerHTML += `<br> <br> base * altura = ??`
        document.getElementById("respuesta"). innerHTML += `<br> <br> Recuerda que esta formula sirve tambien para calcular el area de un rectangulo`
        document.getElementById("respuesta"). innerHTML += `<br> <br> De esa manera obtenemos el area del cuadrado o rectangulo. Espero y te ayude😉.`
    }
    signo_zodiacal(){
        let dia,mes

        //pido los valores
        dia=parseInt(document.getElementById("dia").value)
        mes=document.getElementById("mes").value

        //Convierto en mayuscula el mes
        mes = mes.toUpperCase()

        //condiciono y luego presento

        if ((dia >= 21 && dia <= 31 && mes=="MARZO") || (dia >= 1 && dia <= 19 && mes=="ABRIL")) {
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es ARIES`
            document.getElementById("respuesta").innerHTML +=`<br> Aries forma parte de los signos cardinales y al mismo tiempo es un signo de fuego; también es el primer signo del zodíaco, precisamente por eso, simboliza el inicio, la creación. Se caracteriza por ser una persona rebosante de energía y entusiasmo; avanzada y aventurera, adora la libertad, los retos y las nuevas ideas.`
        }else if((dia >= 20 && dia <= 31 && mes=="ABRIL") || (dia >= 1 && dia <= 20 && mes=="MAYO")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es TAURO`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Tauro pertenece a los signos fijos y simultáneamente es un signo de tierra. La proyección del Sol en su nacimiento suele influir para que sean personas firmes, decididas y constantes en varios sentidos. También adoran sentir seguridad, por eso la buscan tanto, es como una necesidad constante en sus vidas.`
        }else if((dia >= 21 && dia <= 31 && mes=="MAYO") || (dia >= 1 && dia <= 20 && mes=="JUNIO")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es GEMINIS`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Géminis es un signo mutable que forma parte del elemento aire; como signo de los gemelos, su carácter es doble y bastante contradictorio por complejo. Por una parte es capaz de adaptarse con facilidad y rapidez a todo, pero por otra puede resultar hipócrita. Su distintivo común es la comunicación y el ingenio.`
        }else if((dia >= 21 && dia <= 31 && mes=="JUNIO") || (dia >= 1 && dia <= 22 && mes=="JULIO")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es CANCER`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Cáncer es un signo cardinal y comprendido dentro de los signos de agua. De los signos zodiacales, su carácter es el menos claro; puede ser desde retraído, insociable y pelma, hasta deslumbrante, atractivo y admirado por los demás. A veces es demasiado soñador, por eso equivoca el mundo real con la utopía que ha construido en su cabeza: el refugio de las fantasías que adora.`
        }else if((dia >= 23 && dia <= 31 && mes=="JULIO") || (dia >= 1 && dia <= 22 && mes=="AGOSTO")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es LEO`
            document.getElementById("respuesta").innerHTML +=`<br> <br> El signo de Leo es fijo y de fuego, también el signo más dominante del zodíaco. Creativo y abierto, tiene ambición, valor, fuerza, autonomía y total seguridad en sí mismo: sabe dónde quiere llegar y nada ni nadie podrá evitarlo. En contrapartida, sus puntos negativos pueden ser tantos como las virtudes que tiene: vanidad, egocentrismo, arrogancia, impostura y un genio de mil demonios, entre otros defectos.`
        }else if((dia >= 23 && dia <= 31 && mes=="AGOSTO") || (dia >= 1 && dia <= 22 && mes=="SEPTIEMBRE")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es VIRGO`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Virgo es un signo mutable y de tierra; representado por una virgen, es un signo caracterizado por su espíritu crítico, precisión, reserva, paciencia y convencionalismo. También es lógico, metódico y aplicado, le gusta aprender y es capaz de analizar las situaciones más complejas con una claridad pasmosa.`
        }else if((dia >= 23 && dia <= 31 && mes=="SEPTIEMBRE") || (dia >= 1 && dia <= 22 && mes=="OCTUBRE")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es LIBRA`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Libra es un signo cardinal y de aire, se encuentra además entre los signos más refinados del zodíaco; tiene elegancia, encanto, diplomacia y buen gusto, ama la belleza, es muy curioso por naturaleza y odia los conflictos. Sus puntos negativos a veces son la frivolidad y un carácter voluble.`
        }else if((dia >= 23 && dia <= 31 && mes=="OCTUBRE") || (dia >= 1 && dia <= 21 && mes=="NOVIEMBRE")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es ESCORPIO`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Escorpio es un signo fijo y de agua; su potencia y energía emocional son únicas en todo el zodíaco. Tiene mucha imaginación e intuición, además de una gran capacidad para el análisis, fuerza de voluntad y firmeza, aunque también es muy sensible y emocional consigo mismo y con el entorno.`
        }else if((dia >= 22 && dia <= 31 && mes=="NOVIEMBRE") || (dia >= 1 && dia <= 21 && mes=="DICIEMBRE")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es SAGITARIO`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Sagitario pertenece a los signos mutables y su elemento es el fuego; es uno de los signos más resplandecientes y positivos del zodíaco. También es versátil, adora las aventuras y buscar nuevos horizontes, ya que tiene una mente abierta a nuevas ideas y experiencias y mantiene una actitud decidida ante la adversidad; además, frecuentemente la suerte le acompaña.`
        }else if((dia >= 22 && dia <= 31 && mes=="DICIEMBRE") || (dia >= 1 && dia <= 19 && mes=="ENERO")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es CAPRICORNIO`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Capricornio es un signo cardinal y de tierra, y uno de los signos del zodíaco más constante, sólido y apacible. También se caracteriza por ser prudente y práctico en todos los asuntos que le conciernen. Sus aspectos más negativos tienden hacia el pesimismo, la fijeza y la melancolía.`
        }else if((dia >= 20 && dia <= 31 && mes=="ENERO") || (dia >= 1 && dia <= 18 && mes=="FEBRERO")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es ACUARIO`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Acuario es un signo fijo y de aire, y sin duda, es el signo con mayor capacidad para la invención de toda la rueda zodiacal. Simpático, original y brillante, Acuario también es un signo muy humanitario, al mismo tiempo que independiente e intelectual. Sus puntos negativos se encuentran en su inestabilidad e imprecisión y en su tendencia a llevar la contraria casi por sistema.`
        }else if((dia >= 19 && dia <= 29 && mes=="FEBRERO") || (dia >= 1 && dia <= 20 && mes=="MARZO")){
            //se presenta
            document.getElementById("respuesta").innerHTML =`Tu signo es PISCIS`
            document.getElementById("respuesta").innerHTML +=`<br> <br> Piscis es un signo mutable y de agua, también es el último signo del zodiaco, precisamente por eso, es el más rico y complejo de todos. Sensible ante el sufrimiento de los demás, responde con buena voluntad y ganas de ayudar. No le gusta sentirse preso y ni respeta las convenciones, así, por las buenas, aunque tampoco tiende a luchar contra lo establecido, sencillamente, discurre por otro lado.`
        }else {
            document.getElementById("respuesta").innerHTML=`Fecha no encontrada!! Por favor ingrese una fecha valida`
        }

    }
    multiplicacion(){
                // Desactivar el botón de presentar al inicio del juego
                let btn = id('iniciar');
                btn.disabled = true;
        
                // Desactivar los botones de opciones al inicio del juego
                for (let i = 1; i <= 5; i++) {
                    let opcion = id(`opcion${i}`);
                    opcion.disabled = true;
                }
         
                // Genera dos números aleatorios para la suma
                let num1 = Math.floor(Math.random() * 10) + 3;
                let num2 = Math.floor(Math.random() * 10) + 3;
         
                // Calcula la respuesta correcta
                let respuesta_correcta = num1 * num2 
         
                // Genera tres respuestas incorrectas
                let respuestas_incorrectas = [];
                for (let i = 0; i < 4; i++) {
                    let incorrecta;
                    do {
                        incorrecta = Math.floor(Math.random() * 100) + 1;
                    } while (incorrecta === respuesta_correcta || respuestas_incorrectas.includes(incorrecta));
                    respuestas_incorrectas.push(incorrecta);
                }
         
                // Combina las respuestas correctas e incorrectas
                let opciones = [respuesta_correcta, ...respuestas_incorrectas];
         
                // Mezcla las opciones
                opciones.sort(() => Math.random() - 0.5);
         
                // Presenta la pregunta y las opciones
                let preguntaElement = id("pregunta");
                if (preguntaElement) {
                    preguntaElement.innerHTML = `¿Cuánto es ${num1} * ${num2}?`;
                }
                document.getElementById("correcto").innerHTML = `Acertaste = ${cant_correcto}`
                document.getElementById("fallaste").innerHTML = `Fallastes = ${cant_errores}`
                document.getElementById("mostrar").innerHTML = ``;
                document.getElementById("texto").innerHTML = ``;
         
                // Activar los botones de opciones
                for (let i = 1; i <= opciones.length; i++) {
                    let opcion = id(`opcion${i}`);
                    if (opcion) {
                        opcion.innerHTML = opciones[i - 1];
                        opcion.disabled = false;
                        opcion.onclick = function() {
                            // Desactivar los botones de opciones después de seleccionar una respuesta
                            for (let j = 1; j <= opciones.length; j++) {
                                let currentOption = id(`opcion${j}`);
                                if (currentOption) {
                                    currentOption.disabled = true;
                                }
                            }
                
                            if (opciones[i - 1] == respuesta_correcta) {
                                cant_correcto ++
                                document.getElementById("correcto").innerHTML = `Acertaste = ${cant_correcto}`
                                document.getElementById("texto").innerHTML = `Correcto`;
                                document.getElementById("mostrar").innerHTML = `😀`;
                                
                            } else {
                                cant_errores ++
                                document.getElementById("fallaste").innerHTML = `Fallastes = ${cant_errores}`
                                document.getElementById("texto").innerHTML = `Fallaste`;
                                document.getElementById("mostrar").innerHTML = `😥`;
                            }
                
                            // Activar nuevamente el botón de presentar para el próximo juego
                            btn.disabled = false;
                        };
                    }
                }
    }
    contador_de_texto(){

        let numeros = 0, letras = 0, vocales = 0, caracter = 0, palabras = 0

        //pido los valores
        let texto = document.getElementById("texto").value.toLowerCase()

        //se recorre el todo el texto y se hace el conteo
        for (let i = 0; i < texto.length; i++) {
            if (texto[i] >= "0" && texto[i] <= "9") {
                numeros++
            } else if (texto[i] >= "a" && texto[i] <= "z") {
                letras++;
                if ("aeiou".includes(texto[i])) {
                    vocales++
                }
            } else if ("#$%&/()=+-*.,;:[]{}¿?¡!<>_".includes(texto[i])) {
                caracter++
            } else if (texto[i] == " " && texto[i + 1] != " " && i > 0) {
                palabras++
            }
        }

        //aumento el contador de palabras mas 1 para las ultimas palabras que no contienen espacio
        if (texto[texto.length - 1] != " ") {
            palabras++
        }


        //presento los contadores
        document.getElementById("numeros").innerHTML = `<br> Numeros = ${numeros}`
        document.getElementById("letras").innerHTML = `<br> Letras = ${letras}`
        document.getElementById("vocales").innerHTML = `<br> Vocales = ${vocales}`
        document.getElementById("caracter").innerHTML = `<br> Caracter = ${caracter}`
        document.getElementById("palabras").innerHTML = `<br> Palabras = ${palabras}`
    }
    //EL JUEGO SUMA ES DE NIÑOS
    sumas(){
        // Desactivar el botón de presentar al inicio del juego
        let btn = id('iniciar');
        btn.disabled = true;

        // Desactivar los botones de opciones al inicio del juego
        for (let i = 1; i <= 5; i++) {
            let opcion = id(`opcion${i}`);
            opcion.disabled = true;
        }
 
        // Genera dos números aleatorios para la suma
        let num1 = Math.floor(Math.random() * 10) + 1;
        let num2 = Math.floor(Math.random() * 10) + 1;
 
        // Calcula la respuesta correcta
        let respuesta_correcta = num1 + num2 
 
        // Genera tres respuestas incorrectas
        let respuestas_incorrectas = [];
        for (let i = 0; i < 4; i++) {
            let incorrecta;
            do {
                incorrecta = Math.floor(Math.random() * 10) + 1;
            } while (incorrecta === respuesta_correcta || respuestas_incorrectas.includes(incorrecta));
            respuestas_incorrectas.push(incorrecta);
        }
 
        // Combina las respuestas correctas e incorrectas
        let opciones = [respuesta_correcta, ...respuestas_incorrectas];
 
        // Mezcla las opciones
        opciones.sort(() => Math.random() - 0.5);
 
        // Presenta la pregunta y las opciones
        let preguntaElement = id("pregunta");
        if (preguntaElement) {
            preguntaElement.innerHTML = `¿Cuánto es ${num1} + ${num2}?`;
        }
        document.getElementById("correcto").innerHTML = `Acertaste = ${cant_correcto}`
        document.getElementById("fallaste").innerHTML = `Fallastes = ${cant_errores}`
        document.getElementById("mostrar").innerHTML = ``;
        document.getElementById("texto").innerHTML = ``;
 
        // Activar los botones de opciones
        for (let i = 1; i <= opciones.length; i++) {
            let opcion = id(`opcion${i}`);
            if (opcion) {
                opcion.innerHTML = opciones[i - 1];
                opcion.disabled = false;
                opcion.onclick = function() {
                    // Desactivar los botones de opciones después de seleccionar una respuesta
                    for (let j = 1; j <= opciones.length; j++) {
                        let currentOption = id(`opcion${j}`);
                        if (currentOption) {
                            currentOption.disabled = true;
                        }
                    }
        
                    if (opciones[i - 1] == respuesta_correcta) {
                        cant_correcto ++
                        document.getElementById("correcto").innerHTML = `Acertaste = ${cant_correcto}`
                        document.getElementById("texto").innerHTML = `Correcto`;
                        document.getElementById("mostrar").innerHTML = `😀`;
                        
                    } else {
                        cant_errores ++
                        document.getElementById("fallaste").innerHTML = `Fallastes = ${cant_errores}`
                        document.getElementById("texto").innerHTML = `Fallaste`;
                        document.getElementById("mostrar").innerHTML = `😥`;
                    }
        
                    // Activar nuevamente el botón de presentar para el próximo juego
                    btn.disabled = false;
                };
            }
        }

    }
    restas(){
        // Desactivar el botón de presentar al inicio del juego
        let btn = id('iniciar');
        btn.disabled = true;

        // Desactivar los botones de opciones al inicio del juego
        for (let i = 1; i <= 5; i++) {
            let opcion = id(`opcion${i}`);
            opcion.disabled = true;
        }
 
        // Genera dos números aleatorios para la suma
        let num1 = Math.floor(Math.random() * 10) + 1;
        let num2 = Math.floor(Math.random() * 10) + 1;
 
        // Calcula la respuesta correcta
        let respuesta_correcta = num1 - num2 
 
        // Genera tres respuestas incorrectas
        let respuestas_incorrectas = [];
        for (let i = 0; i < 4; i++) {
            let incorrecta;
            do {
                incorrecta = Math.floor(Math.random() * 10) + 1;
            } while (incorrecta === respuesta_correcta || respuestas_incorrectas.includes(incorrecta));
            respuestas_incorrectas.push(incorrecta);
        }
 
        // Combina las respuestas correctas e incorrectas
        let opciones = [respuesta_correcta, ...respuestas_incorrectas];
 
        // Mezcla las opciones
        opciones.sort(() => Math.random() - 0.5);
 
        // Presenta la pregunta y las opciones
        let preguntaElement = id("pregunta");
        if (preguntaElement) {
            preguntaElement.innerHTML = `¿Cuánto es ${num1} - ${num2}?`;
        }
        document.getElementById("correcto").innerHTML = `Acertaste = ${cant_correcto}`
        document.getElementById("fallaste").innerHTML = `Fallastes = ${cant_errores}`
        document.getElementById("mostrar").innerHTML = ``;
        document.getElementById("texto").innerHTML = ``;
 
        // Activar los botones de opciones
        for (let i = 1; i <= opciones.length; i++) {
            let opcion = id(`opcion${i}`);
            if (opcion) {
                opcion.innerHTML = opciones[i - 1];
                opcion.disabled = false;
                opcion.onclick = function() {
                    // Desactivar los botones de opciones después de seleccionar una respuesta
                    for (let j = 1; j <= opciones.length; j++) {
                        let currentOption = id(`opcion${j}`);
                        if (currentOption) {
                            currentOption.disabled = true;
                        }
                    }
        
                    if (opciones[i - 1] == respuesta_correcta) {
                        cant_correcto ++
                        document.getElementById("correcto").innerHTML = `Acertaste = ${cant_correcto}`
                        document.getElementById("texto").innerHTML = `Correcto`;
                        document.getElementById("mostrar").innerHTML = `😀`;
                        
                    } else {
                        cant_errores ++
                        document.getElementById("fallaste").innerHTML = `Fallastes = ${cant_errores}`
                        document.getElementById("texto").innerHTML = `Fallaste`;
                        document.getElementById("mostrar").innerHTML = `😥`;
                    }
        
                    // Activar nuevamente el botón de presentar para el próximo juego
                    btn.disabled = false;
                };
            }
        }
    }
}


function id(elementId){
    return document.getElementById(elementId);
}


let juegos2 = new jovenes()