// se obtiene los id
let seccionBatalla = document.getElementById('campo-batalla')
let msjBatalla = document.getElementById('msj-batalla')
let imgAtaqueJugador = document.getElementById('img-ataque-jugador')
let imagAtaquePc = document.getElementById('img-ataque-pc')
let btnPiedra = document.getElementById('btn-piedra')
let btnPapel = document.getElementById('btn-papel')
let btnTijera = document.getElementById('btn-tijera')

// se define variables
let opcionJugador
let opcionPc
let imgJugador
let imgPc
let contGanastes = 0
let contPerdistes = 0
let contEmpates = 0

//se hace un arreglo de objetos
let imagenes = [

    {
        name : "Piedra",
        url: "/img/piedra.gif"
    },
    {
        name : "Papel",
        url : "/img/papel.gif"
    },
    {
        name : "Tijera",
        url : "/img/tijera.gif"
    }
]

//cuando se refresca la pagina el campo de batalla se borra
function inciar() {
    seccionBatalla.style.display = 'none'
}

//Cuando el usuario haga el click en Piedra pues se ejecutara una funcion
btnPiedra.addEventListener("click" , function(){
    opcionJugador  = "Piedra"
    opPc()
})

//Cuando el usuario haga el Papel en Piedra pues se ejecutara una funcion
btnPapel.addEventListener("click", function(){
    opcionJugador = "Papel"
    opPc()
})

//Cuando el usuario haga el click en Tijera pues se ejecutara una funcion
btnTijera.addEventListener("click", function(){
    opcionJugador = "Tijera"
    opPc()
})

//Se elige una ataque al azar 
function opPc() {
    let aleatorio = nAleatorio()

    if (aleatorio == 0) {
        opcionPc = "Piedra"
    }else if(aleatorio == 1){
        opcionPc = "Papel"
    }else if(aleatorio == 2){
        opcionPc = "Tijera"
    }

    batalla()
}

//condicona si gano o perdio segun la opcion del usuario y la del ataque aleatorio
function batalla(){

    if (opcionJugador == opcionPc) {

        msjBatalla.innerHTML = `Empate 🤔`
        contEmpates ++

    }else if(opcionJugador == "Piedra" && opcionPc == "Tijera"){

        msjBatalla.innerHTML = `Ganastes! 😄`
        contGanastes++

    }else if(opcionJugador == "Papel" && opcionPc == "Piedra"){

        msjBatalla.innerHTML = `Ganastes! 😄`
        contGanastes++
    
    }else if(opcionJugador == "Tijera" && opcionPc =="Papel" ){

        msjBatalla.innerHTML = `Ganastes! 😄`
        contGanastes ++

    }else {

        msjBatalla.innerHTML = `Perdistes 😥`
        contPerdistes++
    }

    document.getElementById('intentos').innerHTML = `  Ganastes: ${contGanastes}`
    document.getElementById('intentos').innerHTML += `<br> <br> Perdiste: ${contPerdistes}`
    document.getElementById('intentos').innerHTML += `<br> <br> Empates: ${contEmpates}`

    addImagens()
}

function addImagens(){

    //se recorre el arreglo IMAGENES
    for (let i = 0; i < imagenes.length; i++) {
        if (opcionJugador == imagenes[i].name) {
            imgJugador = imagenes[i].url
            let inserta = `<img class="img-batalla" src=${imgJugador} alt="imagen no encontrada">`
            imgAtaqueJugador.innerHTML = inserta
        } 

        if (opcionPc == imagenes[i].name) {
            imgPc = imagenes[i].url
            let inserta = `<img class="img-batalla" src=${imgPc} alt="imagen no encontrada">`
            imagAtaquePc.innerHTML = inserta
        }
    }

    seccionBatalla.style.display = 'flex'

}

//se crea un numero aleatorio del 0 al 2 y se retorna el valor
function nAleatorio(){
    let n = Math.floor(Math.random() * 3)
    return n
}

//una vez cargado todo el window pues se llamara a la funcion INICIAR
window.addEventListener("load", inciar)