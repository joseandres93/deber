//defino variables globales
let palabrita
let cant_errores = 0 //erroes
let cant_aciertos = 0 //aciertos

//defino el arreglo palabras
let palabras = ['manzana', 'televisor', 'profesor', 'mesa', 'silla', 'amarillo', 'gato', 'murcielago','lapto','escritorio','naranja','perro','casa','odontologo']

let btn = id('jugar')
let imagen = id ('imagen')
let btn_letras = document.querySelectorAll("#letras button")

//click en iniciar juego
btn.addEventListener('click', iniciar )

function id(str) {
    return document.getElementById(str)
}

//funcion para obtener un numero al azar y compararlo con el array
function obtener_random(num_min,num_max){
    let amplitud_valores = num_max - num_min //valor mas alto - el valor mas bajo del random

    let valor_a_azar = Math.floor(Math.random() * amplitud_valores) + num_min

    return valor_a_azar
}
//funcion de inicio de juego
function iniciar(event) {
    imagen.src = '/img/0.png'
    btn.disabled = true
    for (let i = 0; i < btn_letras.length; i++) {
        btn_letras[i].disabled = false
    }

    cant_errores = 0 //erroes
    cant_aciertos = 0 //aciertos

    let parrafo = id('palabra_a_adivinar')
    //SE REINICIA LOS SPAN
    parrafo.innerHTML = ''

    let cant_palabras = palabras.length
    
    let valor_a_azar = obtener_random(0, cant_palabras)

    palabrita = palabras[valor_a_azar]
    console.log(palabrita)

    let cant_letras = palabrita.length

    for (let i = 0; i < cant_letras; i++) {
        let span = document.createElement('span')
        parrafo.appendChild(span)
    }

}


//click de adivinar letra
for (let i = 0; i < btn_letras.length; i++) {
    btn_letras[i].addEventListener('click', click_letras)
    
}

function click_letras(event) {
    let spans = document.querySelectorAll('#palabra_a_adivinar span')

    let button = event.target //cual de todas las letras,llamo a la funcion
    //desabilito el boton de las letras una vez ya se allan usado
    button.disabled=true

    //convierto todas la letras en miniscula para minizar errores
    let letra = button.innerHTML.toLowerCase()
    let palabra = palabrita.toLowerCase()

    let acierto = false

    //se recorre las palabra y se comprueba laletra ingresada
    for (let i = 0; i < palabra.length; i++) {
        if (letra == palabra[i]) {
            //la variable i es la posicion de la letra en la palabra que coincide con el span que debemos mostrar la letra
            spans[i].innerHTML = letra
            cant_aciertos++
            acierto = true
        }
        
    }
    if (acierto == false) {
        cant_errores++
        let source = `/img/${cant_errores}.png`
        let imagen = id('imagen')
        imagen.src = source
    }

    if (cant_errores == 7) {
        id('resultado').innerHTML = `Perdistes, la palabra era [${palabrita}]`
        game_over()
    }else if(cant_aciertos == palabrita.length){
        id('resultado').innerHTML = `Ganastes!!`
        game_over()
    }
    console.log("la letra " + letra + " en la palabra " + palabra + " existe? " + acierto)
}

//fin del juego
function game_over() {
    for (let i = 0; i < btn_letras.length; i++) {
        btn_letras[i].disabled = true
        
    }

    btn.disabled = false
}
game_over()